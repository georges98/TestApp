package com.company.testapp.model

data class User(
    var id:Int       = 0,
    var email:String = "",
    var password:String = ""
    )

